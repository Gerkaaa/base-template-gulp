# base-template-gulp
Base template with gulp

# step 1
`npm i`

# development
`gulp dev`

# build project
`gulp build`